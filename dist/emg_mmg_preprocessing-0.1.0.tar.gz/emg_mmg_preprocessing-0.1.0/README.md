# EMG_MMG_Preprocessing
Pipeline to load and preprocess EMG and MMG data
